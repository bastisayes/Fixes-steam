addappid(1144200) -- Ready or Not
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6") -- Ready Or Not - Alpha Content
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
addappid(1844910) -- Ready or Not Supporter Edition
addappid(3015760) -- Ready or Not Home Invasion
addappid(3174120) -- Ready or Not Dark Waters

-- Made with love by LightningFast⚡💜
