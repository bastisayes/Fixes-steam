addappid(275850, 1, "bb6b75fde9bed39524f38b15f4421448e580935048bc0105a7943f893e20974a") -- No Man's Sky
addappid(275851, 1, "a5ce5217e5d5d20115ea81209764d4e89f37bed55b84690951d5df23e73852a6") -- No Man's Sky Content
addappid(275852, 1, "1f8fb10eb2401484d32af8e6c0d3b7e4148e78e4cf8f632afe1ab6600fb7e57d") -- Depot 275852
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(513130) -- Pre-Order Horizon Omega Ship
addappid(2790030) -- No Man's Sky - Entitlement

-- Made with love by LightningFast⚡💜
