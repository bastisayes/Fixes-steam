addappid(3454980) -- Mortal Kombat: Legacy Kollection
addappid(3454981, 1, "a411f1c5ad0ff5f71b4e8aab564c7fd8fbd44ac3598a07480f2af377bcf65a9f") -- Depot 3454981
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)

-- Made with love by LightningFast⚡💜
