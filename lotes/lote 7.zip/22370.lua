addappid(22370) -- Fallout 3 - Game of the Year Edition
addappid(22371, 1, "4069e70a8a61568f540e8d6e7dabfcbe023909bc7423b7bcde27f916522fd6c9") -- fallout 3 goty content
addappid(22372, 1, "992a52b45d1b8af30bcc671ea17458c8cd25785e847c3f4ded78e1235cf25a03") -- Fallout 3: Game of the Year Edition French
addappid(22373, 1, "46ab6de47092933c1b88ff77f62d3050e519e29058052a97d301acf46c2980e7") -- Fallout 3: Game of the Year Edition German
addappid(22374, 1, "9e2a7fd390fdab4dca859aec379e420b50bdb8b15fe5b23c4f01d7040cef5de9") -- Fallout 3: Game of the Year Edition Spanish
addappid(22375, 1, "cf22e4172975f6c93ea05c6f2583c36154c90319229ef6d78e518abe641ea27a") -- Fallout 3: Game of the Year Edition Italian
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)

-- Made with love by LightningFast⚡💜
