addappid(1252330) -- DEATHLOOP
addappid(1252334, 1, "3ea9535dac5d1d028071a51bba6b1993ca3ab210f4bbf52b03b7d660b8251420") -- video
addappid(1252335, 1, "de090e863404b3885ae8e9eb767aa33efad7cfede6fb56746698ca83d8accb26") -- content_0
addappid(1252336, 1, "3a6b5870c39881a67e8397504d3b76a99e8d15dfc4cedda444be478c30055ca3") -- English
addappid(1252337, 1, "087c22f74642923f9419910cddef82d4b4fbe3b62249428994eb037ae6f31a62") -- French
addappid(1252338, 1, "e2584921d3668d9fc419378630d33bb1cdf2c850278e9a2959948ab0109b3d5d") -- Italian
addappid(1252339, 1, "5439bc9d1b198659064db03136914f302e953e8508654b3fe20ab6fd9238e92d") -- German
addappid(1468560, 1, "234a2af60458cce44cb1ea4046323fa73b043c61045d7284b13a8f55c4dc4f81") -- Spanish
addappid(1468561, 1, "580fc41e84dc165c29246cd53ad943efa0e2dbc23bf6862d109242ee6dc5b90a") -- Russian
addappid(1468562, 1, "89b085f18aacdeb6679d962aafe4f082a19ebdf7103145f963a30a2ce330b737") -- Polish
addappid(1468563, 1, "4df00396ffc322183c891cc2f6998fa2115800fc97f6dc739bdaa43e33d4ffad") -- MexicanSpanish
addappid(1468564, 1, "b531b64db753e37c1f62d1c5203aa2b7308114ed6ed652c50f456487504e4ecd") -- BrazilianPortuguese
addappid(1468565, 1, "e238ef96bd90d4836e4820f693c4e2843252ed026958950550dd9cc5e55f97b9") -- SimplifiedChinese
addappid(1468566, 1, "c11f92cf9a3362c871b83013635ee30df206413c39b1db3f988d5e9d5b3d9082") -- Japanese
addappid(1468567, 1, "6b8ae305c0cae0dc8457d285651c6051613c0146d40949007b111057b935f183") -- Korean
addappid(1468568, 1, "a470d26eaa6293cdd2131db5fcf14ef84ad3e60ec2035b40e1e46df73170fd95") -- TraditionalChinese
addappid(1468569, 1, "bab0fad2a278921d63f60926fe6e504b7c8bdd66061415a3d500fd22ea803512") -- Arabic
addappid(1468573, 1, "e6ee3526293b32a5ae22920f4055e6696e1380faf5dbaea3c1b43a7d42e638a8") -- Shipping_exe
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1457700)
addappid(1457700, 1, "2f2dd5204db57e08ba78a9d1ad9c8318862be2d71bab34746a320112bd8715f7") -- DEATHLOOP - PreOrder - DEATHLOOP - PreOrder (1457700) Depot
addappid(1457701) -- DEATHLOOP - Deluxe
addappid(1843490) -- DEATHLOOP Deluxe Pack

-- Made with love by LightningFast