addappid(3654560) -- Plants vs. Zombies™: Replanted
addappid(3654561, 1, "6fc167060f8d59e04b1336aa831531599eba25b5d81a6d659408e1d69b65b456") -- Depot 3654561
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3802680) -- Retro Peashooter Skin Pre-Order Bonus

-- Made with love by LightningFast⚡💜