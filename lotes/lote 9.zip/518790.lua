addappid(518790) -- theHunter: Call of the Wild™
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Depot 1 (228988_6645201662696499616.manifest)
addappid(518791,0,"c56059a25b086342342b536c815b9903ee3faa35b8358fe7556346fe60a9081e") -- Depot 2 (518791_4272873070129891426.manifest)

-- Made with love by LightningFast⚡💜
