addappid(264710) -- Subnautica
addappid(264712,0,"d764b2a41e9bdbf338f04948309614ea6f8d462073a610940aaf10cbfc35aa85") -- Depot 1 (264712_3638894940716012854.manifest)
addappid(264713,0,"6da396b527d2b570a039778566cef5c1e94ba486fefa835553a1831e40353dec") -- Depot 2 (264713_6406809907156750445.manifest)

-- Made with love by LightningFast⚡💜
