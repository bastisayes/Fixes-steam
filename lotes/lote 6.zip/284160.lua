addappid(284160) -- BeamNG.drive
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Depot 1 (228988_6645201662696499616.manifest)
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- Depot 2 (228990_1829726630299308803.manifest)
addappid(284161,0,"0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229") -- Depot 3 (284161_2141501966764359676.manifest)

-- Made with love by LightningFast⚡💜
