addappid(242050, 1, "cafa8e00c75d44d7e693fab3646f3e5803ada60a2dd26534ead5874dccdc4869") -- Assassin's Creed IV Black Flag
addappid(242051, 1, "6b4004c38a5c8c1a869d90c381726c7d5651f578753c316c2dcd372fa13ef609") -- Assassin’s Creed IV Black Flag Content
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
addappid(260476)
addappid(260476, 1, "c6245eb9d4c77c2f2204ab40754a0d50402bb78f9de10b495e2f9df94d0c051d") -- Assassins Creed Black Flag - Freedom Cry (SP) - Assassin's Creed Black Flag - Freedom Cry (SP) (260476) Depot
addappid(264803)
addappid(264803, 1, "28fe23f7e6ef14d6190c4b1646a87d9d7aa6d22d7a0f89936abfe3ebd293fd80") -- Assassins Creed Black Flag - Freedom Cry Pack Activation Key - Assassin's Creed Black Flag - Freedom Cry Pack Activation Key (264803) Depot
addappid(260470) -- Assassins Creed Black Flag - Resources Pack
addappid(260471) -- Assassins Creed Black Flag - Collectibles Pack
addappid(260472) -- Assassins Creed Black Flag - Activities Pack
addappid(260473) -- Assassins Creed Black Flag - Death Vessel Pack (SP)
addappid(260474) -- Assassins Creed Black Flag - Crusader  Florentine Pack (SP)
addappid(260477) -- Assassins Creed Black Flag - Illustrious Pirates Pack (SP)
addappid(260478) -- Assassins Creed Black Flag - Guild of Rogues (SP)
addappid(260950) -- Assassins Creed Black Flag - Season Pass
addappid(264750) -- Assassins Creed Black Flag - Technology Pack
addappid(264800) -- Assassins Creed Black Flag - Death Vessel Pack Activation Key
addappid(264801) -- Assassins Creed Black Flag - Crusader  Florentine Pack Activation Key
addappid(264802) -- Assassins Creed Black Flag - Blackbeards Wrath Pack Activation Key
addappid(264804) -- Assassins Creed Black Flag - Illustrious Pirates Pack Activation Key
addappid(264805) -- Assassins Creed Black Flag - Guild of Rogues Pack Activation Key
addappid(264810) -- Assassins Creed IV Black Flag - Standard Edition Activation Key
addappid(264811) -- Assassins Creed IV Black Flag - Standard Edition Pre-Order Activation Key
addappid(264812) -- Assassins Creed IV Black Flag - Gold Edition Activation Key
addappid(264813) -- Assassins Creed IV Black Flag - Deluxe Edition Activation Key
addappid(265320) -- Assassins Creed IV Black Flag - Deluxe Edition Pre-Order Activation Key
addappid(1650420) -- Assassins Creed IV Black Flag - Gold Uplay activation

-- Made with love by LightningFast⚡💜
