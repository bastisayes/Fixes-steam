addappid(2144740) -- Ghostrunner 2
addappid(2144741, 1, "d8c29346c26cded430d2454682d4c10c4b3ae1605e872fd1a8a829ecb79e1de4") -- Depot 2144741
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
addappid(2573290) -- Ghostrunner 2 - Pre Order Content
addappid(2573300) -- Ghostrunner 2 - Deluxe Content
addappid(2573310) -- Ghostrunner 2  - Brutal Content
addappid(2574920) -- Ghostrunner 2 - Season Pass
addappid(2691130) -- Ghostrunner 2 - Ice Pack
addappid(2769320) -- Ghostrunner 2 - Dragon Pack
addappid(2988270) -- Ghostrunner 2 - Heat Pack
addappid(3092910) -- Ghostrunner 2 - Endless Moto Mode
addappid(3232490) -- Ghostrunner 2 - Anniversary Pack

-- Made with love by LightningFast⚡💜
