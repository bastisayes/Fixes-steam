addappid(631510) -- Devil May Cry HD Collection
addappid(631511, 1, "79183f987f646ce0abe58d2a413285f83e8bc0d045c01864d28e30bb6ee37ae2") -- hifumi Content
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(811840)
addappid(811840, 1, "16b5d8916c93e2e48652438e21a29ca27db96cdf30f095c95d0ee9eec24cf34b") -- DMCHDC Wallpaper - DMCHDC Wallpaper (811840) Depot

-- Made with love by LightningFast⚡💜
