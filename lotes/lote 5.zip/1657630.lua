addappid(1657630) -- Slime Rancher 2
addappid(1657631,0,"a37c1409dc2c7880fc988d25d9fa333438bab756f17f7d0fc27015c8ef2faed3") -- Depot 1 (1657631_8022624175545882077.manifest)

-- Made with love by LightningFast⚡💜
