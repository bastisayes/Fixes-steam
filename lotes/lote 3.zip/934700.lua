addappid(934700) -- Dead Island 2
addappid(934701, 1, "9f01bb4de4308fcda3524d8e086fb30c2cee5a647bc41b8ca77afad561bde375") -- Depot 934701
addappid(934702, 1, "74f4653f5c8cd21938bd4a269765ee3310d860bbf57e7fcc44dd02751f277a49") -- Depot 934702
addappid(934703, 1, "58de2f171f82b74cb47ade0cbc87eb4a5046814bdf0bf1b6d359625a63543852") -- Depot 934703
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2667910) -- Dead Island 2 - Kingdom Come Deliverance II Weapons Pack
addappid(2813000) -- Dead Island 2 - Memories of Banoi Pack
addappid(2813010) -- Dead Island 2 - Golden Weapons Pack
addappid(2813020) -- Dead Island 2 - Pulp Weapons Pack
addappid(2813030) -- Dead Island 2 - Reds Demise Katana
addappid(2813040) -- Dead Island 2 - Character Pack Silver Star Jacob
addappid(2813050) -- Dead Island 2 - Character Pack Cyber Slayer Amy
addappid(2813060) -- Dead Island 2 - Character Pack Gaelic Queen Dani
addappid(2813070) -- Dead Island 2 - Character Pack Jungle Fantasy Ryan
addappid(2813080) -- Dead Island 2 - Character Pack Steel Horse Carla
addappid(2813090) -- Dead Island 2 - Character Pack Venice Vogue Bruno
addappid(2813100) -- Dead Island 2 - Haus
addappid(2813110) -- Dead Island 2 - Expansion Pass
addappid(2813310) -- Dead Island 2 - SoLA

-- Made with love by LightningFast⚡💜
