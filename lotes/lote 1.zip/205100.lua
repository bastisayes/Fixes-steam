addappid(205100) -- Dishonored
addappid(205101, 1, "42107f3f2d8fde4d980e3de5a3b6a9548497675b97fb5be88e578964c24991ce") -- DepotDishonoredGame
addappid(205102, 1, "1e60f542dfd33d42eef0d45965f5c7a19a6949eb1ec97f399700dbc3c85d7dc8") -- DepotDishonoredLangINT
addappid(205103, 1, "ed518fd42aef448c1043fe291a80632e85207242b8d4d18f7f51a4a80bc644aa") -- DepotDishonoredLangFRA
addappid(205104, 1, "0cf761fe1cf22a43fa7daba45af5368cd11e40fd5e5f8cff7a154f2cf7434090") -- DepotDishonoredLangITA
addappid(205105, 1, "a5edbaafa3576d51111b4438ae92e73c92252a0970b1c6ed8367fc7db8a1ce18") -- DepotDishonoredLangDEU
addappid(205106, 1, "f406f5908d05fc3baa1c5655ca150862c08a29163d2e956d45c22ca43a55ef35") -- DepotDishonoredLangESN
addappid(205107, 1, "4c832577b21680c03a9dfc8e66a8e7448e5233b9f9037c123be0a7fb36e32dbe") -- DepotDishonoredExecutables
addappid(208570)
addappid(208570, 1, "d5f8adf6db0731cd395883db60b943cf3c83d2d447084a3111822237c1f56fe4") -- Dishonored Dunwall City Trials DLC - DLC1
addappid(208575)
addappid(208575, 1, "ccddbb489f2ba68ba8ab5239862de740f6bfe8871f1d6336bc9364cbf012dd4c") -- Dishonored The Knife of Dunwall - DLC2
addappid(212894)
addappid(212894, 1, "9db7ad1dd15bd13765ae84a6b4f3a6fb5d6947c4c334781e68f96d244989e52f") -- Dishonored The Brigmore Witches - DLC3
addappid(212890) -- Dishonored Shadow Rat Pack
addappid(212891) -- Dishonored Backstreet Butcher Pack
addappid(212892) -- Dishonored Arcane Assassin Pack
addappid(212893) -- Dishonored Void Walkers Arsenal

-- Made with love by LightningFast⚡💜
