addappid(1282100) -- Remnant II
addappid(1282101, 1, "c44eaabd20d9d5479bea7e31ad0a7c0571d120c77b28814ed4175f6f790fdf7f") -- Depot 1282101
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2384070) -- Remnant II - Survival Pack
addappid(2384071) -- Remnant II - DLC Bundle
addappid(2384072) -- Remnant II - Gunslinger Unlock
addappid(2384073) -- Remnant 2 - The Awakened King
addappid(2384074) -- Remnant II - The Forgotten Kingdom
addappid(2384075) -- Remnant II - The Dark Horizon
addappid(2384076) -- Remnant II - Deluxe Edition Items

-- Made with love by LightningFast