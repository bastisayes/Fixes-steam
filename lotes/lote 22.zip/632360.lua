addappid(632360) -- Risk of Rain 2
addappid(632361,0,"074d702b52f219d0d3440d09a1ded40e4ab4468c8a77b96dd97b1467a3e1a9f0") -- Depot 1 (632361_2195879929166828140.manifest)
addappid(228988,0,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Depot 2 (228988_6645201662696499616.manifest)

-- Made with love by LightningFast